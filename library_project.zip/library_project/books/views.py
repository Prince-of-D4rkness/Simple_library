from django.shortcuts import render, redirect, get_object_or_404
from .models import Book
from rest_framework import viewsets
from .serializers import BookSerializer

# Create your views here.

class BookViewSet(viewsets.ModelViewSet):
    queryset = Book.objects.all()
    serializer_class = BookSerializer
    
    
    

def book_list(request):
    books = Book.objects.all()
    return render(request, 'books/book_list.html', {'books': books})
  
#CRUD
def add_book(request):
  if request.method == 'POST':
    title = request.POST.get('title')
    author = request.POST.get('author')
    published_date = request.POST.get('published_date')
    genre = request.POST.get('genre')
    
    if title and author:
      Book.objects.create(
        title=title,
        author=author,
        published_date=published_date,
        genre=genre
      )
    return redirect('book_list')
  
  return render(request, 'books/add_book.html')

def delete_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    book.delete()
    return redirect('book_list')

def edit_book(request, book_id):
  book = get_object_or_404(Book, id=book_id)
  
  if request.method == 'POST':
      book.title = request.POST.get('title')
      book.author = request.POST.get('author')
      book.published_date = request.POST.get('published_date')
      book.genre = request.POST.get('genre')
      book.save()
      return redirect('book_list')
  
  return render(request, 'books/add_book.html')

def book_detail(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    return render(request, 'books/book_detail.html', {'book' : book})

