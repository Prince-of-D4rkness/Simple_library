from django.urls import path, include
from rest_framework import routers
from .views import BookViewSet
from . import views

router = routers.DefaultRouter()
router.register(r'books', BookViewSet)

urlpatterns = [
    path('', views.book_list, name='book_list'),
    path('<int:book_id>/', views.book_detail, name='book_detail'),
    path('add/', views.add_book, name='add_book'),
    path('edit/<int:book_id>/', views.edit_book, name='edit_book'),
    path('delete/<int:book_id>/', views.delete_book, name='delete_book'),
    path('api/', include(router.urls)),
]
